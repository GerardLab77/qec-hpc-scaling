#!/bin/bash

REAL_PATH="$(realpath $0)"
export EXEC_PATH="$(dirname "$REAL_PATH")"

export OUTPUT_PATH="$EXEC_PATH"/qstone_runs
export PROFILE_PATH="$EXEC_PATH"/qstone_profile

rm -rf $LOCKFILE
. "$EXEC_PATH"/initialise.sh
mkdir -p "$OUTPUT_PATH"
mkdir -p "$PROFILE_PATH"
export PROJECT_NAME="CHANGE_ME"
export JOB_COUNT="1"
export SCHEDULING_MODE="NONE"
export QPU_MODE="EMULATED"
export CONNECTIVITY_MODE="NO_LINK"
export CONNECTIVITY_QPU_IP_ADDRESS="127.0.0.1"
export CONNECTIVITY_QPU_PORT="0"
export PROG_ID="0"
export QS_USER="qec"
python "$EXEC_PATH"/type_exec.py OfflineQEC 1 0 1 2 gAR9lC4=